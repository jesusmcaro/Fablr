## Fablr Read-Me:

#### Introduction:
Fablr is an api wrapper for the faker package that allows you to easily generate fake pandas dataframes. It is designed to be easy to use, easy to understand, and fully reproducible. The purpose for creating this package is to take the hassle out of generating fake data for testing, or modeling purposes. Using the Fablr package, you can easily generate a simple data-model, and plug the data model into mock or POC etl pipelines, tests, or populate a database model with synthetic data .

